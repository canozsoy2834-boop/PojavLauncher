OzsoyMC tasarim paketi. Kaynaklar oz_ oneklidir, Pojav'inkilerle cakismaz.
Manifest'te kullanilacak: @style/Theme.OzsoyMC, @mipmap/ic_launcher, @string/oz_app_name
