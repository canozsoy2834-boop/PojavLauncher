package com.ozsoymc.launcher

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket

data class ServerStatus(val online: Int, val max: Int)

/** Gercek Minecraft Server List Ping. Basarisizsa null doner (sahte veri GOSTERME). */
object ServerStatusPinger {
    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while (true) {
            if (v and 0x7F.inv() == 0) { out.writeByte(v); return }
            out.writeByte((v and 0x7F) or 0x80)
            v = v ushr 7
        }
    }

    private fun readVarInt(input: DataInputStream): Int {
        var result = 0; var shift = 0
        while (true) {
            val b = input.readUnsignedByte()
            result = result or ((b and 0x7F) shl shift)
            if (b and 0x80 == 0) return result
            shift += 7
            if (shift > 35) throw RuntimeException("VarInt cok uzun")
        }
    }

    /** Arka plan thread'inde cagir (Dispatchers.IO). */
    fun ping(host: String = "mc.ozsoymc.com.tr", port: Int = 25565, timeoutMs: Int = 4000): ServerStatus? = try {
        Socket().use { s ->
            s.soTimeout = timeoutMs
            s.connect(InetSocketAddress(host, port), timeoutMs)
            val out = DataOutputStream(s.getOutputStream())
            val input = DataInputStream(s.getInputStream())

            val hs = ByteArrayOutputStream()
            DataOutputStream(hs).apply {
                writeVarInt(this, 0x00)
                writeVarInt(this, 760)            // protokol numarasi, durum icin onemsiz
                val h = host.toByteArray(Charsets.UTF_8)
                writeVarInt(this, h.size); write(h)
                writeShort(port)
                writeVarInt(this, 1)              // next state: status
            }
            writeVarInt(out, hs.size()); out.write(hs.toByteArray())
            writeVarInt(out, 1); writeVarInt(out, 0x00)   // status request
            out.flush()

            readVarInt(input)                      // paket uzunlugu
            readVarInt(input)                      // paket id
            val len = readVarInt(input)
            val buf = ByteArray(len); input.readFully(buf)
            val players = JSONObject(String(buf, Charsets.UTF_8)).getJSONObject("players")
            ServerStatus(players.getInt("online"), players.getInt("max"))
        }
    } catch (e: Exception) { null }
}
