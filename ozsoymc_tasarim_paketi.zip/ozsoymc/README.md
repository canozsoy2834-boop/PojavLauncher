# OzsoyMC Launcher - tasarim paketi (1. asama)

Kopyalama:
- res/ icindekileri Pojav projesinde app_pojavlauncher/src/main/res/ icine birlestir.
- kotlin/ServerStatusPinger.kt'yi kod paketine ekle (package satirini projene gore duzelt).

Pojav'da AndroidManifest.xml icinde application etiketine:
  android:theme="@style/Theme.OzsoyMC"
  android:icon="@mipmap/ic_launcher"
  android:roundIcon="@mipmap/ic_launcher_round"
  android:label="@string/app_name"

Mevcut ayni isimli kaynaklar (strings, colors) cakisirsa Pojav'inkileri yeniden adlandirma, benimkilere oz_ oneki veriyoruz.
Imza: <include layout="@layout/view_developer_signature"/>  (Gelistirici beyaz, TurkSplash kirmizi)
Sunucu durumu: lifecycleScope.launch(Dispatchers.IO){ val s = ServerStatusPinger.ping() ... }
